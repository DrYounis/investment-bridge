-- ============================================================
-- مرفأ — الحزمة الموحدة: إدراج 3 حالات سعودية بنمط محلي/أجنبي/محلي
-- ⛔ هذا السكربت يحل محل niceone-meeting8-shift.sql
--    و elm-meeting9-shift.sql — لا تنفذهما إطلاقاً.
-- ⛔ يفترض قاعدة البيانات بحالتها الأصلية (لقاءات 1–14).
--
-- الترتيب النهائي: 8=نايس ون | 9=Netflix | 10=علم | 11=Google
--                  12=التعاونية | 13=Theranos | … | 17=Quibi
--
-- Run manually in Supabase SQL Editor, in the same sitting as the
-- consolidated Qwen deploy, strictly BEFORE Friday Aug 7, 2026.
-- Meetings 1–7 are untouched (Sat Aug 1 cron unaffected).
-- ============================================================

-- ── 0) Preflight A: check for CHECK constraints that might cap
--       meeting_number at 14. If any row shows "meeting_number <= 14",
--       STOP and send me the output.
SELECT conrelid::regclass AS table_name, conname, pg_get_constraintdef(oid)
FROM pg_constraint
WHERE contype = 'c'
  AND conrelid::regclass::text IN
    ('majlis_quiz_questions','majlis_quiz_answers','majlis_messages','majlis_message_likes');

-- ── 0) Preflight B: confirm original state (expect: max = 14, question 8 = Netflix-era)
SELECT max(meeting_number) FROM majlis_quiz_questions;

-- ── 1) Shift old meeting_number → new positions (descending = no collisions)
--       Mapping: 14→17, 13→16, 12→15, 11→14, 10→13, 9→11, 8→9
BEGIN;

-- quiz questions (UNIQUE on meeting_number)
UPDATE majlis_quiz_questions SET meeting_number = 17 WHERE meeting_number = 14;
UPDATE majlis_quiz_questions SET meeting_number = 16 WHERE meeting_number = 13;
UPDATE majlis_quiz_questions SET meeting_number = 15 WHERE meeting_number = 12;
UPDATE majlis_quiz_questions SET meeting_number = 14 WHERE meeting_number = 11;
UPDATE majlis_quiz_questions SET meeting_number = 13 WHERE meeting_number = 10;
UPDATE majlis_quiz_questions SET meeting_number = 11 WHERE meeting_number = 9;
UPDATE majlis_quiz_questions SET meeting_number = 9  WHERE meeting_number = 8;

-- quiz answers
UPDATE majlis_quiz_answers SET meeting_number = 17 WHERE meeting_number = 14;
UPDATE majlis_quiz_answers SET meeting_number = 16 WHERE meeting_number = 13;
UPDATE majlis_quiz_answers SET meeting_number = 15 WHERE meeting_number = 12;
UPDATE majlis_quiz_answers SET meeting_number = 14 WHERE meeting_number = 11;
UPDATE majlis_quiz_answers SET meeting_number = 13 WHERE meeting_number = 10;
UPDATE majlis_quiz_answers SET meeting_number = 11 WHERE meeting_number = 9;
UPDATE majlis_quiz_answers SET meeting_number = 9  WHERE meeting_number = 8;

-- majlis chat messages
UPDATE majlis_messages SET meeting_number = 17 WHERE meeting_number = 14;
UPDATE majlis_messages SET meeting_number = 16 WHERE meeting_number = 13;
UPDATE majlis_messages SET meeting_number = 15 WHERE meeting_number = 12;
UPDATE majlis_messages SET meeting_number = 14 WHERE meeting_number = 11;
UPDATE majlis_messages SET meeting_number = 13 WHERE meeting_number = 10;
UPDATE majlis_messages SET meeting_number = 11 WHERE meeting_number = 9;
UPDATE majlis_messages SET meeting_number = 9  WHERE meeting_number = 8;

-- message likes
UPDATE majlis_message_likes SET meeting_number = 17 WHERE meeting_number = 14;
UPDATE majlis_message_likes SET meeting_number = 16 WHERE meeting_number = 13;
UPDATE majlis_message_likes SET meeting_number = 15 WHERE meeting_number = 12;
UPDATE majlis_message_likes SET meeting_number = 14 WHERE meeting_number = 11;
UPDATE majlis_message_likes SET meeting_number = 13 WHERE meeting_number = 10;
UPDATE majlis_message_likes SET meeting_number = 11 WHERE meeting_number = 9;
UPDATE majlis_message_likes SET meeting_number = 9  WHERE meeting_number = 8;

COMMIT;

-- ── 2) Insert the three HBS-style questions
INSERT INTO majlis_quiz_questions (meeting_number, question, updated_at) VALUES
(8, 'أنت مستشار استُدعي لمجلس إدارة نايس ون بعد إعلان خسارة الربع الثاني 2026 (خسارة صافية 19.93 مليون ريال بهامش -10.5%، بعد أن كان هامش الربح 7.13% في عام 2024). أمام الإدارة ثلاثة خيارات: خفض حاد للمصاريف التسويقية، أو رفع الأسعار مع قبول انخفاض حجم المبيعات، أو الاستمرار في حرق الهامش للدفاع عن الحصة السوقية. أي خيار توصي به ولماذا؟ وما أول ثلاثة أرقام تطلبها من المدير المالي قبل اتخاذ قرارك؟', now()),
(10, 'أنت عضو مستقل في مجلس إدارة عِلم عام 2024، وأمامك عرض الاستحواذ على "ثقة" من صندوق الاستثمارات العامة — المساهم الأكبر في شركتك — مقابل 3.4 مليار ريال (نحو 19 ضعف أرباح ثقة السنوية البالغة 180 مليون)، بتمويل معظمه دين. مهمتك حماية صغار المساهمين: ما الشروط الثلاثة التي تضعها قبل التصويت بالموافقة؟ وما المؤشر الذي ستراقبه بعد الصفقة لتحكم خلال سنتين هل كانت قراراً صائباً أم شراء نموٍ بأي ثمن؟', now()),
(12, 'أنت رئيس قطاع الاكتتاب في التعاونية عام 2026: معدل الخسارة في قطاع الممتلكات عاد يرتفع نحو متوسطه التاريخي (~60%) بعد سنة استثنائية عند 37%، ومنافس جديد يخفض الأسعار بناءً على تلك السنة الجيدة ليكسب حصة سوقية. أمامك ثلاثة خيارات: مجاراة التخفيض للحفاظ على الحصة، أو التمسك بالتسعير الفني وقبول خسارة عملاء، أو إعادة توجيه النمو لقطاع آخر. ما قرارك ولماذا؟ وما المؤشران اللذان يثبتان بعد سنتين أن قرارك كان الصحيح؟', now())
ON CONFLICT (meeting_number)
DO UPDATE SET question = EXCLUDED.question, updated_at = now();

-- ── 3) Post-checks
-- expect: 8=نايس ون, 9=Netflix السابق, 10=علم, 11=Google السابق, 12=التعاونية, 13..17 = البقية بالترتيب, لا فجوات
SELECT meeting_number, left(question, 40) FROM majlis_quiz_questions ORDER BY meeting_number;
SELECT meeting_number, count(*) FROM majlis_quiz_answers GROUP BY 1 ORDER BY 1;
SELECT meeting_number, count(*) FROM majlis_messages GROUP BY 1 ORDER BY 1;
