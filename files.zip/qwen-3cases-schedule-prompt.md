# Qwen Prompt — الحزمة الموحدة: 3 حالات سعودية بنمط محلي/أجنبي/محلي (الجدول يصبح 17 لقاءً)

> ⛔ **This prompt SUPERSEDES and REPLACES** `qwen-niceone-meeting8-prompt.md` and `qwen-elm-meeting9-prompt.md`. Do not run those. This is a single-pass change against the ORIGINAL repo state (14 sessions).

Repo: `~/Desktop/marfa.sa/investment-bridge` (branch `main`). Stack: Next.js 16 / React 19 / TypeScript / Tailwind v4 (CSS-first). Work ONLY on the files listed below.

## CONTEXT
The Marfa Council schedule currently has 14 weekly Friday sessions (base Friday: June 19, 2026), with local (Saudi) and international cases. We are inserting three Saudi trending cases, deliberately interleaved with international ones (محلي/أجنبي/محلي pattern). Final order:

| # | Case | Origin | Friday |
|---|------|--------|--------|
| 1–7 | unchanged | — | — |
| 8 | **نايس ون (NEW)** | محلي | Aug 7 |
| 9 | Netflix (was 8) | أجنبي | Aug 14 |
| 10 | **عِلم (NEW)** | محلي | Aug 21 |
| 11 | Google Aristotle (was 9) | أجنبي | Aug 28 |
| 12 | **التعاونية (NEW)** | محلي | Sep 4 |
| 13 | Theranos (was 10) | أجنبي | Sep 11 |
| 14 | IKEA (was 11) | — | Sep 18 |
| 15 | J&J (was 12) | — | Sep 25 |
| 16 | Patagonia (was 13) | — | Oct 2 |
| 17 | Quibi (was 14) | — | Oct 9 |

Supabase `meeting_number` data is shifted by a separate SQL script run manually — DO NOT write any migration or touch Supabase schema.

There is a known code smell you will fix as part of this task: `SCHEDULE_DATA` and the Friday-date helpers are **duplicated** between `app/components/marfa/scheduleData.ts` (the declared single source of truth) and `app/components/marfa/MeetingsSchedule.tsx` (a stale local copy). After this change, `MeetingsSchedule.tsx` must import everything from `scheduleData.ts`.

## PROHIBITIONS (non-negotiable)
- Do NOT create/modify any API route, auth logic, cron logic (beyond the numeric bound constants listed in 2.3), env vars, or dependencies.
- Do NOT touch Supabase clients, RLS, or SQL. No schema work.
- Do NOT modify the content of meetings 1–7 in any way, and do not alter any field of the shifted entries except their `encounter` label.
- Do NOT reformat unrelated code or "improve" anything outside the file list.
- Do NOT create PDF files — the six files below are provided separately and will already exist in `public/case-studies/`; just reference their paths:
  `NiceOne_Margins_Case_Study.pdf`, `NiceOne_Margins_Arabic_Case_Study.pdf`, `Elm_MnA_Case_Study.pdf`, `Elm_MnA_Arabic_Case_Study.pdf`, `Tawuniya_Insurance_Case_Study.pdf`, `Tawuniya_Insurance_Arabic_Case_Study.pdf`
- No raw error messages to clients; no new `catch {}` blocks anywhere. If any new server-side code seems necessary, STOP and report instead of writing it.

### SECURITY & PRIVACY REQUIREMENTS
[الصق هنا PART A كاملاً من `marfa-security-standard-new-features.md` — إلزامي في كل برومبت]

---

## PHASE 1 — AUDIT (read-only, report findings before editing)

```bash
grep -n "i < 14" app/components/marfa/scheduleData.ts app/components/marfa/MeetingsSchedule.tsx
grep -c "encounter:" app/components/marfa/scheduleData.ts                  # expect 14
grep -c "const SCHEDULE_DATA" app/components/marfa/MeetingsSchedule.tsx    # expect 1 (the duplicate)
grep -n "n > 14\|n < 1" "app/meetings/majlis/[meetingNumber]/page.tsx"
grep -n "> 14\|1–14" app/api/admin/majlis-quiz/route.ts
grep -n "<= 14\|> 14" app/api/cron/majlis-quiz-reminder/route.ts app/api/cron/majlis-quiz-reminder-midweek/route.ts
grep -n "n <= 14" app/admin/majlis/page.tsx
```

Expected current state: `scheduleData.ts` has 14 entries and `getFridayDates()` loops `i < 14`; `MeetingsSchedule.tsx` contains its own duplicated `SCHEDULE_DATA` array and a `getWeeklyFridaySchedule()` helper with `i < 14`; hardcoded bound `14` exists in `app/meetings/majlis/[meetingNumber]/page.tsx` (~line 12), `app/api/admin/majlis-quiz/route.ts` (~lines 17–18 and 67–68), `app/api/cron/majlis-quiz-reminder/route.ts` (~lines 41, 155, 163), `app/api/cron/majlis-quiz-reminder-midweek/route.ts` (~lines 90, 96), and `app/admin/majlis/page.tsx` (~line 79). If reality differs materially (e.g. some of this was already applied), STOP and report.

---

## PHASE 2 — IMPLEMENT

### 2.1 `app/components/marfa/scheduleData.ts` — the three insertions
Insert the following three entries, matching the existing single-line object style of the file:

**(a) At index 7** — immediately AFTER اللقاء 7 (Saudi German Health) and BEFORE Netflix:

```ts
{ encounter: "اللقاء 8", topic: "تآكل الهوامش", case: 'حالة "نايس ون" (تداول: 4193)', challenge: "من هامش ربح 7.13% في «السنة الذهبية» 2024 (مبيعات تجاوزت المليار ريال) إلى خسارة صافية 19.93 مليون ريال في الربع الثاني 2026 بهامش -10.5%. كيف تتآكل الأرباح رغم ثبات المبيعات؟ وما علامات الإنذار المبكر التي كان يجب رصدها منذ الإدراج؟", pdf: "/case-studies/NiceOne_Margins_Case_Study.pdf", arPdf: "/case-studies/NiceOne_Margins_Arabic_Case_Study.pdf", glossaryKeywords: ["هامش", "ربحية", "خسارة", "إيرادات", "تكلفة", "نمو", "قوائم مالية", "اكتتاب", "إدراج", "سيولة"] },
```

**(b) Immediately AFTER the Netflix entry** (Netflix becomes اللقاء 9; this becomes index 9):

```ts
{ encounter: "اللقاء 10", topic: "الاندماج والاستحواذ", case: 'حالة "عِلم" (تداول: 7203) — صفقة ثقة', challenge: "استحواذ عِلم على «ثقة» من صندوق الاستثمارات العامة — مساهمها الأكبر — بـ 3.4 مليار ريال (~19 ضعف الأرباح) بتمويل معظمه دين. متى يكون شراء النمو أذكى من بنائه؟ وكيف تُحمى حقوق صغار المساهمين في صفقات الأطراف ذات العلاقة؟", pdf: "/case-studies/Elm_MnA_Case_Study.pdf", arPdf: "/case-studies/Elm_MnA_Arabic_Case_Study.pdf", glossaryKeywords: ["استحواذ", "اندماج", "شهرة", "تقييم", "تمويل", "دين", "حوكمة", "مساهم", "تآزر", "أطراف ذات علاقة"] },
```

**(c) Immediately AFTER the Google Project Aristotle entry** (Google becomes اللقاء 11; this becomes index 11):

```ts
{ encounter: "اللقاء 12", topic: "اقتصاديات التأمين", case: 'حالة "التعاونية" (تداول: 8010) — سرّ العائم', challenge: "هامش صافٍ ~5% فقط — نفس الرقم الذي أنذر بانهيار نايس ون — لكنه هنا نموذج ممتاز: محفظة استثمارات 12.6 مليار ريال ممولة من أقساط العملاء تدر 764 مليون سنوياً. متى يكون الهامش الرفيع صحياً؟ وما ضوابط «العائم» حتى لا يتحول امتيازه إلى دين؟", pdf: "/case-studies/Tawuniya_Insurance_Case_Study.pdf", arPdf: "/case-studies/Tawuniya_Insurance_Arabic_Case_Study.pdf", glossaryKeywords: ["تأمين", "اكتتاب", "أقساط", "مطالبات", "عائم", "معدل الخسارة", "إعادة تأمين", "ملاءة", "استثمار", "هامش"] },
```

**(d) Renumber ONLY the `encounter` label strings of the shifted entries:** Netflix → `"اللقاء 9"`, Google Project Aristotle → `"اللقاء 11"`, Theranos → `"اللقاء 13"`, IKEA → `"اللقاء 14"`, Johnson & Johnson → `"اللقاء 15"`, Patagonia → `"اللقاء 16"`, Quibi → `"اللقاء 17"`. Do not change any other field of those entries.

**(e)** After the `SCHEDULE_DATA` array declaration, add:

```ts
export const TOTAL_MEETINGS = SCHEDULE_DATA.length; // 17
```

**(f)** In `getFridayDates()`, change the loop bound `i < 14` → `i < 17` and add the comment `// keep in sync with SCHEDULE_DATA.length`.

### 2.2 `app/components/marfa/MeetingsSchedule.tsx` — de-duplicate
a. DELETE the local `SCHEDULE_DATA` array and the local helpers `getWeeklyFridaySchedule()`, `formatDate()`, and `getThisFridayIndex()`.
b. Add: `import { SCHEDULE_DATA, formatDate, getFridayDates, getThisFridayIndex } from './scheduleData';`
c. Replace the `getWeeklyFridaySchedule()` call in the component with `getFridayDates()`.
d. Keep `METHOD_STEPS` and all JSX/markup exactly as they are.
e. In the table card header, change `جدول لقاءات مرفأ (6 أشهر)` → `جدول لقاءات مرفأ (17 لقاءً أسبوعياً)`.

### 2.3 Numeric bounds → `TOTAL_MEETINGS`
In each file below, import `TOTAL_MEETINGS` from `@/app/components/marfa/scheduleData` (or extend the existing scheduleData import) and replace the hardcoded `14`:

- `app/meetings/majlis/[meetingNumber]/page.tsx`: `n > 14` → `n > TOTAL_MEETINGS`
- `app/api/admin/majlis-quiz/route.ts`: both bound checks `> 14` → `> TOTAL_MEETINGS`; update both error strings `1–14` → `` `1–${TOTAL_MEETINGS}` ``
- `app/api/cron/majlis-quiz-reminder/route.ts`: `nextN <= 14` (~41), `finishedN > 14` (~155), `nextN <= 14` (~163) → `TOTAL_MEETINGS`
- `app/api/cron/majlis-quiz-reminder-midweek/route.ts`: `finishedN > 14` (~90), `nextN <= 14` (~96) → `TOTAL_MEETINGS`
- `app/admin/majlis/page.tsx`: `for (let n = 1; n <= 14; n++)` → `n <= TOTAL_MEETINGS`

Do NOT touch any other `14` in these files (e.g. `14px` styles, `font-size: 14px`).

---

## PHASE 3 — VERIFY (must all pass before committing)

```bash
# 1. 17 entries; the three Saudi cases present at correct positions (expect: 17 / one match each)
grep -c "encounter:" app/components/marfa/scheduleData.ts
grep -n "نايس ون\|عِلم\|التعاونية" app/components/marfa/scheduleData.ts

# 2. Interleaving correct (expect: اللقاء 8 نايس ون → اللقاء 9 Netflix → اللقاء 10 عِلم → اللقاء 11 Google → اللقاء 12 التعاونية)
grep -o 'encounter: "اللقاء [0-9]*"' app/components/marfa/scheduleData.ts

# 3. No duplicated schedule left in MeetingsSchedule (expect: 0 / 1 import line)
grep -c "const SCHEDULE_DATA" app/components/marfa/MeetingsSchedule.tsx
grep -n "from './scheduleData'" app/components/marfa/MeetingsSchedule.tsx

# 4. No stale numeric bounds (expect: no output)
grep -n "i < 14" app/components/marfa/scheduleData.ts app/components/marfa/MeetingsSchedule.tsx
grep -rn "> 14\|<= 14" "app/meetings/majlis/[meetingNumber]/page.tsx" app/api/admin/majlis-quiz/route.ts app/api/cron/majlis-quiz-reminder/route.ts app/api/cron/majlis-quiz-reminder-midweek/route.ts app/admin/majlis/page.tsx | grep -v "14px\|z-1\|w-14\|h-14"

# 5. TOTAL_MEETINGS wired everywhere (expect: 6+ matches across files)
grep -rn "TOTAL_MEETINGS" app | grep -v node_modules

# 6. Renumbering complete (expect: exactly one match each for 8..17; اللقاء 17 = Quibi)
for n in 8 9 10 11 12 13 14 15 16 17; do echo -n "اللقاء $n: "; grep -c "اللقاء $n\"" app/components/marfa/scheduleData.ts; done

# 7. Header updated (expect: 1 match)
grep -n "17 لقاءً" app/components/marfa/MeetingsSchedule.tsx

# 8. Build passes
npm run build
```

Output a summary table `Check # | Status | Evidence`. If any check fails, report it — do not patch beyond scope. Then commit with message:
`feat(majlis): add Nice One, Elm, Tawuniya Saudi cases interleaved with international ones; schedule to 17; dedupe SCHEDULE_DATA`

Report the commit SHA when done.
